import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";
dotenv.config();

const db = new Database("pezeshkyar.db", { readonly: true });
const dir = process.env.BACKUP_DIR || "./backups";
const retention = Number(process.env.BACKUP_RETENTION_DAYS || 14);
fs.mkdirSync(dir,{recursive:true});

const stamp=new Date().toISOString().replace(/[:.]/g,"-");
const target=path.join(dir,`pezeshkyar-${stamp}.db`);
await db.backup(target);
db.close();

const now=Date.now();
for(const f of fs.readdirSync(dir)){
  const p=path.join(dir,f);
  try{
    if(now-fs.statSync(p).mtimeMs > retention*86400000) fs.rmSync(p);
  }catch{}
}
console.log("Backup created:",target);
