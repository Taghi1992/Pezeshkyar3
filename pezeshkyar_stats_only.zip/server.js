import express from "express";
import https from "node:https";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import Stripe from "stripe";
import dotenv from "dotenv";
import { z } from "zod";
import { authenticator } from "otplib";
import crypto from "node:crypto";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const db = new Database("pezeshkyar.db");
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-me";
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || true }));
app.use(express.json({ limit: "100kb" }));
app.use(rateLimit({ windowMs: 15*60*1000, limit: 300, standardHeaders: true }));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT UNIQUE NOT NULL,
 phone TEXT,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('patient','doctor','admin')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 mfa_enabled INTEGER NOT NULL DEFAULT 0,
 mfa_secret TEXT,
 mfa_pending_secret TEXT
);
CREATE TABLE IF NOT EXISTS doctors(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER UNIQUE NOT NULL,
 specialty TEXT NOT NULL,
 fee INTEGER NOT NULL,
 bio TEXT DEFAULT '',
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS medical_records(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 patient_id INTEGER UNIQUE NOT NULL,
 file_number TEXT UNIQUE,
 birth_date TEXT,
 national_id TEXT,
 allergies TEXT DEFAULT '',
 history TEXT DEFAULT '',
 medications TEXT DEFAULT '',
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(patient_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS appointments(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 patient_id INTEGER NOT NULL,
 doctor_id INTEGER NOT NULL,
 date TEXT NOT NULL,
 time TEXT NOT NULL,
 visit_type TEXT NOT NULL,
 amount INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 payment_status TEXT NOT NULL DEFAULT 'unpaid',
 payment_ref TEXT,
 payment_token TEXT,
 payment_gateway TEXT,
 payment_error TEXT,
 payment_verified_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(doctor_id,date,time),
 FOREIGN KEY(patient_id) REFERENCES users(id),
 FOREIGN KEY(doctor_id) REFERENCES doctors(id)
);
`);

for (const [col,type] of [["payment_token","TEXT"],["payment_gateway","TEXT"],["payment_error","TEXT"],["payment_verified_at","TEXT"]]) {
  try { db.exec(`ALTER TABLE appointments ADD COLUMN ${col} ${type}`); } catch {}
}

try { db.exec("ALTER TABLE medical_records ADD COLUMN file_number TEXT"); } catch {}
try { db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_medical_file_number ON medical_records(file_number)"); } catch {}
try { db.exec(`CREATE TABLE IF NOT EXISTS medical_files(
 id INTEGER PRIMARY KEY AUTOINCREMENT, patient_id INTEGER NOT NULL, filename TEXT NOT NULL,
 original_name TEXT NOT NULL, mime_type TEXT DEFAULT '', size INTEGER DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`); } catch {}
function ensureFileNumber(patientId){
 let r=db.prepare("SELECT file_number FROM medical_records WHERE patient_id=?").get(patientId);
 if(r?.file_number)return r.file_number;
 const n=`P-${String(patientId).padStart(6,"0")}`;
 try{db.prepare("UPDATE medical_records SET file_number=? WHERE patient_id=?").run(n,patientId);return n}catch{return `P-${Date.now()}-${patientId}`}
}

try { db.exec(`CREATE TABLE IF NOT EXISTS subscription_plans(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 duration_days INTEGER NOT NULL,
 price INTEGER NOT NULL DEFAULT 0,
 features TEXT NOT NULL DEFAULT '[]',
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS doctor_subscriptions(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 doctor_id INTEGER NOT NULL,
 plan_id INTEGER NOT NULL,
 starts_at TEXT,
 ends_at TEXT,
 status TEXT NOT NULL DEFAULT 'pending',
 payment_status TEXT NOT NULL DEFAULT 'unpaid',
 payment_ref TEXT,
 payment_token TEXT,
 payment_error TEXT,
 payment_verified_at TEXT,
 activation_source TEXT NOT NULL DEFAULT 'payment',
 activated_by INTEGER,
 disabled_at TEXT,
 disabled_by INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_doctor_subscriptions_doctor ON doctor_subscriptions(doctor_id,status);
CREATE TABLE IF NOT EXISTS subscription_payments(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 doctor_subscription_id INTEGER NOT NULL,
 amount INTEGER NOT NULL,
 gateway TEXT,
 status TEXT NOT NULL DEFAULT 'pending',
 reference TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`); } catch {}

for (const [col,type] of [["activation_source","TEXT"],["activated_by","INTEGER"],["disabled_at","TEXT"],["disabled_by","INTEGER"]]) {
 try { db.exec(`ALTER TABLE doctor_subscriptions ADD COLUMN ${col} ${type}`); } catch {}
}
function seed(){
  const count = db.prepare("SELECT COUNT(*) c FROM users").get().c;
  if(count) return;
  const insert = db.prepare("INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,?)");
  const p = bcrypt.hashSync("Patient123!", 12);
  const d = bcrypt.hashSync("Doctor123!", 12);
  const a = bcrypt.hashSync("Admin123!", 12);
  const patient = insert.run("بیمار نمونه","patient@pezeshkyar.local","09000000000",p,"patient");
  const doctorUser = insert.run("دکتر سارا احمدی","doctor@pezeshkyar.local","09111111111",d,"doctor");
  insert.run("مدیر سامانه","admin@pezeshkyar.local","09222222222",a,"admin");
  db.prepare("INSERT INTO doctors(user_id,specialty,fee,bio) VALUES(?,?,?,?)")
    .run(doctorUser.lastInsertRowid,"متخصص داخلی",350000,"پزشک متخصص داخلی و مراقبت‌های اولیه");
  db.prepare("INSERT INTO medical_records(patient_id) VALUES(?)").run(patient.lastInsertRowid);
}
seed();

function auth(req,res,next){
  const h=req.headers.authorization||"";
  const token=h.startsWith("Bearer ")?h.slice(7):null;
  if(!token) return res.status(401).json({error:"ورود لازم است"});
  try{ req.user=jwt.verify(token,JWT_SECRET); next(); }
  catch{ return res.status(401).json({error:"نشست نامعتبر یا منقضی شده است"}); }
}
function role(...roles){ return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:"دسترسی مجاز نیست"}); }
function tokenFor(user){ return jwt.sign({id:user.id,name:user.name,email:user.email,role:user.role},JWT_SECRET,{expiresIn:"2h"}); }

const authSchema=z.object({email:z.string().email(),password:z.string().min(8),name:z.string().min(2).max(100).optional(),phone:z.string().max(30).optional()});

app.post("/api/auth/register",(req,res)=>{
  const parsed=authSchema.safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"اطلاعات ثبت‌نام نامعتبر است"});
  const {email,password,name,phone}=parsed.data;
  try{
    const info=db.prepare("INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,?)")
      .run(name, email, phone||"", bcrypt.hashSync(password,12), "patient");
    db.prepare("INSERT INTO medical_records(patient_id) VALUES(?)").run(info.lastInsertRowid);
    const user=db.prepare("SELECT id,name,email,phone,role FROM users WHERE id=?").get(info.lastInsertRowid);
    res.status(201).json({user,token:tokenFor(user)});
  }catch(e){res.status(409).json({error:"این ایمیل قبلاً ثبت شده است"});}
});
app.post("/api/auth/login",(req,res)=>{
  const parsed=authSchema.pick({email:true,password:true}).safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:"ایمیل یا رمز عبور نامعتبر است"});
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(parsed.data.email);
  if(!user || !bcrypt.compareSync(parsed.data.password,user.password_hash)) return res.status(401).json({error:"ایمیل یا رمز عبور اشتباه است"});
  if(user.mfa_enabled){
    const otp=String(req.body.otp||"").replace(/\\s/g,"");
    if(!/^\\d{6}$/.test(otp) || !authenticator.check(otp,user.mfa_secret))
      return res.status(401).json({error:"کد MFA لازم است یا نادرست است",mfa_required:true});
  }
  res.json({user:{id:user.id,name:user.name,email:user.email,phone:user.phone,role:user.role,mfa_enabled:!!user.mfa_enabled},token:tokenFor(user)});
});

app.get("/api/doctors",(req,res)=>{
  res.json(db.prepare(`SELECT d.id,u.name,d.specialty,d.fee,d.bio FROM doctors d JOIN users u ON u.id=d.user_id ORDER BY u.name`).all());
});
app.get("/api/me",auth,(req,res)=>{
  const u=db.prepare("SELECT id,name,email,phone,role FROM users WHERE id=?").get(req.user.id);
  res.json(u);
});

app.get("/api/patients/search",auth,(req,res)=>{
 if(!["doctor","admin"].includes(req.user.role))return res.status(403).json({error:"دسترسی مجاز نیست"});
 const q=String(req.query.q||"").trim(); if(!q)return res.json([]);
 const like=`%${q}%`;
 const rows=db.prepare(`SELECT u.id,u.name,u.phone,u.email,mr.file_number,mr.national_id,mr.birth_date,mr.gender,mr.blood_type,mr.allergies,mr.history,mr.medications
 FROM users u LEFT JOIN medical_records mr ON mr.patient_id=u.id WHERE u.role='patient'
 AND (u.name LIKE ? OR u.phone LIKE ? OR mr.national_id LIKE ? OR mr.file_number LIKE ?) ORDER BY u.name LIMIT 50`).all(like,like,like,like);
 rows.forEach(x=>{if(!x.file_number)x.file_number=ensureFileNumber(x.id)}); res.json(rows);
});
app.get("/api/patients/:id/record",auth,(req,res)=>{
 if(!["doctor","admin"].includes(req.user.role))return res.status(403).json({error:"دسترسی مجاز نیست"});
 const id=Number(req.params.id);
 const p=db.prepare(`SELECT u.id,u.name,u.phone,u.email,mr.file_number,mr.national_id,mr.birth_date,mr.gender,mr.blood_type,mr.allergies,mr.history,mr.medications
 FROM users u LEFT JOIN medical_records mr ON mr.patient_id=u.id WHERE u.id=? AND u.role='patient'`).get(id);
 if(!p)return res.status(404).json({error:"بیمار پیدا نشد"});
 p.file_number ||= ensureFileNumber(id);
 p.appointments=db.prepare(`SELECT a.id,a.date,a.time,a.status,a.payment_status,a.visit_type,d.id doctor_id,du.name doctor_name,d.specialty
 FROM appointments a JOIN doctors d ON d.id=a.doctor_id JOIN users du ON du.id=d.user_id WHERE a.patient_id=? ORDER BY a.date DESC,a.time DESC LIMIT 100`).all(id);
 p.notes=db.prepare(`SELECT vn.*,a.date,a.time,du.name doctor_name,d.specialty FROM visit_notes vn JOIN appointments a ON a.id=vn.appointment_id JOIN doctors d ON d.id=vn.doctor_id JOIN users du ON du.id=d.user_id WHERE vn.patient_id=? ORDER BY vn.created_at DESC LIMIT 100`).all(id);
 p.attachments=db.prepare(`SELECT id,original_name,mime_type,size,created_at FROM medical_files WHERE patient_id=? ORDER BY created_at DESC`).all(id);
 res.json(p);
});
app.get("/api/patients/:id/contact",auth,(req,res)=>{
 if(!["doctor","admin"].includes(req.user.role))return res.status(403).json({error:"دسترسی مجاز نیست"});
 const p=db.prepare("SELECT name,phone FROM users WHERE id=? AND role='patient'").get(Number(req.params.id));
 if(!p)return res.status(404).json({error:"بیمار پیدا نشد"});
 res.json({name:p.name,phone:p.phone||"",tel:p.phone?`tel:${p.phone}`:""});
});
app.get("/api/record",auth,role("patient"),(req,res)=>{
  res.json(db.prepare("SELECT birth_date,national_id,allergies,history,medications,updated_at FROM medical_records WHERE patient_id=?").get(req.user.id)||{});
});
app.put("/api/record",auth,role("patient"),(req,res)=>{
  const s=z.object({birth_date:z.string().max(20).optional(),national_id:z.string().max(30).optional(),allergies:z.string().max(5000).optional(),history:z.string().max(10000).optional(),medications:z.string().max(5000).optional()}).safeParse(req.body);
  if(!s.success)return res.status(400).json({error:"اطلاعات پرونده نامعتبر است"});
  const r=s.data;
  db.prepare(`INSERT INTO medical_records(patient_id,birth_date,national_id,allergies,history,medications)
    VALUES(?,?,?,?,?,?) ON CONFLICT(patient_id) DO UPDATE SET birth_date=excluded.birth_date,national_id=excluded.national_id,allergies=excluded.allergies,history=excluded.history,medications=excluded.medications,updated_at=CURRENT_TIMESTAMP`)
    .run(req.user.id,r.birth_date||"",r.national_id||"",r.allergies||"",r.history||"",r.medications||"");
  res.json({ok:true});
});


app.post("/api/mfa/setup",auth,async(req,res)=>{
  const secret=authenticator.generateSecret();
  db.prepare("UPDATE users SET mfa_pending_secret=? WHERE id=?").run(secret,req.user.id);
  const user=db.prepare("SELECT email FROM users WHERE id=?").get(req.user.id);
  const otpauth=authenticator.keyuri(user.email,"Pezeshkyar",secret);
  res.json({secret,otpauth});
});
app.post("/api/mfa/enable",auth,(req,res)=>{
  const otp=String(req.body.otp||"").replace(/\s/g,"");
  const u=db.prepare("SELECT mfa_pending_secret FROM users WHERE id=?").get(req.user.id);
  if(!u?.mfa_pending_secret || !/^\d{6}$/.test(otp) || !authenticator.check(otp,u.mfa_pending_secret))
    return res.status(400).json({error:"کد MFA نامعتبر است"});
  db.prepare("UPDATE users SET mfa_enabled=1,mfa_secret=mfa_pending_secret,mfa_pending_secret=NULL WHERE id=?").run(req.user.id);
  res.json({ok:true});
});
app.post("/api/mfa/disable",auth,(req,res)=>{
  const otp=String(req.body.otp||"").replace(/\s/g,"");
  const u=db.prepare("SELECT mfa_secret,mfa_enabled FROM users WHERE id=?").get(req.user.id);
  if(!u?.mfa_enabled || !authenticator.check(otp,u.mfa_secret)) return res.status(400).json({error:"کد MFA نامعتبر است"});
  db.prepare("UPDATE users SET mfa_enabled=0,mfa_secret=NULL,mfa_pending_secret=NULL WHERE id=?").run(req.user.id);
  res.json({ok:true});
});


function doctorIdForUser(userId){
  return db.prepare("SELECT id FROM doctors WHERE user_id=?").get(userId)?.id;
}
app.get("/api/doctor/profile",auth,role("doctor"),(req,res)=>{
  const d=db.prepare(`SELECT d.id,u.name,u.email,u.phone,d.specialty,d.fee,d.bio
    FROM doctors d JOIN users u ON u.id=d.user_id WHERE d.user_id=?`).get(req.user.id);
  if(!d)return res.status(404).json({error:"پروفایل پزشک پیدا نشد"});
  res.json(d);
});
app.put("/api/doctor/profile",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const s=z.object({name:z.string().min(2).max(100),phone:z.string().max(30).optional(),specialty:z.string().min(2).max(100),fee:z.number().int().positive().max(100000000),bio:z.string().max(5000).optional()}).safeParse(req.body);
  if(!d||!s.success)return res.status(400).json({error:"اطلاعات نامعتبر است"});
  const row=db.prepare("SELECT user_id FROM doctors WHERE id=?").get(d);
  db.prepare("UPDATE users SET name=?,phone=? WHERE id=?").run(s.data.name,s.data.phone||"",row.user_id);
  db.prepare("UPDATE doctors SET specialty=?,fee=?,bio=? WHERE id=?").run(s.data.specialty,s.data.fee,s.data.bio||"",d);
  res.json({ok:true});
});

app.get("/api/doctors/:id",auth,(req,res)=>{
 const d=db.prepare(`SELECT d.id,u.name,d.specialty,d.fee,d.bio FROM doctors d JOIN users u ON u.id=d.user_id WHERE d.id=?`).get(Number(req.params.id));
 if(!d)return res.status(404).json({error:"پزشک پیدا نشد"});
 res.json(d);
});
app.get("/api/doctors/:doctorId/slots",auth,(req,res)=>{
  const doctorId=Number(req.params.doctorId);
  const date=String(req.query.date||"");
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return res.status(400).json({error:"تاریخ نامعتبر است"});
  const d=db.prepare("SELECT id FROM doctors WHERE id=?").get(doctorId);
  if(!d)return res.status(404).json({error:"پزشک پیدا نشد"});
  const weekday=new Date(date+"T00:00:00").getDay();
  const av=db.prepare("SELECT start_time,end_time FROM doctor_availability WHERE doctor_id=? AND weekday=? ORDER BY start_time").all(doctorId,weekday);
  const taken=new Set(db.prepare("SELECT time FROM appointments WHERE doctor_id=? AND date=? AND status NOT IN ('cancelled','expired')").all(doctorId,date).map(x=>x.time));
  const config=db.prepare("SELECT slot_minutes,break_minutes FROM doctor_slot_settings WHERE doctor_id=?").get(doctorId)||{slot_minutes:30,break_minutes:0};
  const slots=[];
  for(const r of av){
    let [h,m]=r.start_time.split(":").map(Number), [eh,em]=r.end_time.split(":").map(Number);
    let cur=h*60+m,end=eh*60+em;
    while(cur+config.slot_minutes<=end){
      const time=String(Math.floor(cur/60)).padStart(2,"0")+":"+String(cur%60).padStart(2,"0");
      slots.push({time,available:!taken.has(time)});
      cur+=config.slot_minutes+config.break_minutes;
    }
  }
  const now=new Date(), today=now.toISOString().slice(0,10);
  if(date===today){
    const current=now.getHours()*60+now.getMinutes();
    for(const x of slots){const [h,m]=x.time.split(":").map(Number); if(h*60+m<=current)x.available=false;}
  }
  res.json({date,weekday,slot_minutes:config.slot_minutes,slots});
});
app.get("/api/doctor/slot-settings",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  res.json(db.prepare("SELECT slot_minutes,break_minutes FROM doctor_slot_settings WHERE doctor_id=?").get(d)||{slot_minutes:30,break_minutes:0});
});
app.put("/api/doctor/slot-settings",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const x=z.object({slot_minutes:z.number().int().refine(v=>[15,20,30,45,60].includes(v)),break_minutes:z.number().int().min(0).max(60)}).safeParse(req.body);
  if(!d||!x.success)return res.status(400).json({error:"تنظیمات نوبت نامعتبر است"});
  db.prepare(`INSERT INTO doctor_slot_settings(doctor_id,slot_minutes,break_minutes) VALUES(?,?,?)
    ON CONFLICT(doctor_id) DO UPDATE SET slot_minutes=excluded.slot_minutes,break_minutes=excluded.break_minutes`).run(d,x.data.slot_minutes,x.data.break_minutes);
  res.json({ok:true});
});

app.get("/api/doctor/availability",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  res.json(db.prepare("SELECT * FROM doctor_availability WHERE doctor_id=? ORDER BY weekday,start_time").all(d||-1));
});
app.post("/api/doctor/availability",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const s=z.object({weekday:z.number().int().min(0).max(6),start_time:z.string().regex(/^\d{2}:\d{2}$/),end_time:z.string().regex(/^\d{2}:\d{2}$/)}).safeParse(req.body);
  if(!d||!s.success)return res.status(400).json({error:"زمان کاری نامعتبر است"});
  if(s.data.start_time>=s.data.end_time)return res.status(400).json({error:"ساعت پایان باید بعد از شروع باشد"});
  try{const x=db.prepare("INSERT INTO doctor_availability(doctor_id,weekday,start_time,end_time) VALUES(?,?,?,?)").run(d,s.data.weekday,s.data.start_time,s.data.end_time);res.status(201).json({id:x.lastInsertRowid})}
  catch{res.status(409).json({error:"این بازه کاری قبلاً ثبت شده است"})}
});
app.delete("/api/doctor/availability/:id",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  db.prepare("DELETE FROM doctor_availability WHERE id=? AND doctor_id=?").run(Number(req.params.id),d);
  res.json({ok:true});
});
app.get("/api/doctor/statistics",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  if(!d)return res.status(404).json({error:"پروفایل پزشک پیدا نشد"});
  const days=Math.min(Math.max(Number(req.query.days||30),7),365);
  const since=new Date(Date.now()-days*86400000).toISOString();
  const totalPatients=db.prepare("SELECT COUNT(DISTINCT patient_id) n FROM appointments WHERE doctor_id=?").get(d).n||0;
  const newPatients=db.prepare(`SELECT COUNT(*) n FROM (SELECT patient_id,MIN(created_at) first_at FROM appointments WHERE doctor_id=? GROUP BY patient_id) x WHERE first_at>=?`).get(d,since).n||0;
  const today=new Date().toISOString().slice(0,10), month=new Date().toISOString().slice(0,7);
  const todayAppointments=db.prepare("SELECT COUNT(*) n FROM appointments WHERE doctor_id=? AND substr(created_at,1,10)=?").get(d,today).n||0;
  const monthAppointments=db.prepare("SELECT COUNT(*) n FROM appointments WHERE doctor_id=? AND substr(created_at,1,7)=?").get(d,month).n||0;
  const revenue=db.prepare("SELECT COALESCE(SUM(amount),0) n FROM appointments WHERE doctor_id=? AND payment_status='paid'").get(d).n||0;
  const periodRevenue=db.prepare("SELECT COALESCE(SUM(amount),0) n FROM appointments WHERE doctor_id=? AND payment_status='paid' AND created_at>=?").get(d,since).n||0;
  const daily=db.prepare(`SELECT substr(created_at,1,10) day,COUNT(DISTINCT patient_id) patients,COUNT(*) appointments,COALESCE(SUM(CASE WHEN payment_status='paid' THEN amount ELSE 0 END),0) revenue FROM appointments WHERE doctor_id=? AND created_at>=? GROUP BY day ORDER BY day`).all(d,since);
  const statuses=db.prepare("SELECT status,COUNT(*) n FROM appointments WHERE doctor_id=? AND created_at>=? GROUP BY status").all(d,since);
  const payments=db.prepare("SELECT payment_status status,COUNT(*) n FROM appointments WHERE doctor_id=? AND created_at>=? GROUP BY payment_status").all(d,since);
  res.json({days,totalPatients,newPatients,todayAppointments,monthAppointments,revenue,periodRevenue,daily,statuses,payments});
});
app.get("/api/doctor/appointments",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const rows=db.prepare(`SELECT a.*,u.name patient_name,u.phone patient_phone,
    r.birth_date,r.national_id,r.allergies,r.history,r.medications,
    vn.id note_id,vn.diagnosis,vn.prescription,vn.notes visit_notes
    FROM appointments a JOIN users u ON u.id=a.patient_id
    LEFT JOIN medical_records r ON r.patient_id=a.patient_id
    LEFT JOIN visit_notes vn ON vn.appointment_id=a.id
    WHERE a.doctor_id=? ORDER BY a.date,a.time`).all(d||-1);
  res.json(rows);
});
app.put("/api/doctor/appointments/:id/status",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const status=z.enum(["confirmed","completed","cancelled","pending"]).safeParse(req.body.status);
  if(!status.success)return res.status(400).json({error:"وضعیت نامعتبر است"});
  const a=db.prepare("SELECT id FROM appointments WHERE id=? AND doctor_id=?").get(Number(req.params.id),d);
  if(!a)return res.status(404).json({error:"نوبت پیدا نشد"});
  db.prepare("UPDATE appointments SET status=? WHERE id=?").run(status.data,a.id);
  res.json({ok:true});
});
app.get("/api/doctor/appointments/:id/note",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const a=db.prepare("SELECT id,patient_id FROM appointments WHERE id=? AND doctor_id=?").get(Number(req.params.id),d);
  if(!a)return res.status(404).json({error:"نوبت پیدا نشد"});
  res.json(db.prepare("SELECT diagnosis,prescription,notes FROM visit_notes WHERE appointment_id=?").get(a.id)||{diagnosis:"",prescription:"",notes:""});
});
app.put("/api/doctor/appointments/:id/note",auth,role("doctor"),(req,res)=>{
  const d=doctorIdForUser(req.user.id);
  const a=db.prepare("SELECT id,patient_id FROM appointments WHERE id=? AND doctor_id=?").get(Number(req.params.id),d);
  if(!a)return res.status(404).json({error:"نوبت پیدا نشد"});
  const x=z.object({diagnosis:z.string().max(10000).optional(),prescription:z.string().max(10000).optional(),notes:z.string().max(10000).optional()}).safeParse(req.body);
  if(!x.success)return res.status(400).json({error:"یادداشت نامعتبر است"});
  db.prepare(`INSERT INTO visit_notes(appointment_id,doctor_id,patient_id,diagnosis,prescription,notes)
    VALUES(?,?,?,?,?,?) ON CONFLICT(appointment_id) DO UPDATE SET diagnosis=excluded.diagnosis,prescription=excluded.prescription,notes=excluded.notes,updated_at=CURRENT_TIMESTAMP`)
    .run(a.id,d,a.patient_id,x.data.diagnosis||"",x.data.prescription||"",x.data.notes||"");
  db.prepare("UPDATE appointments SET status='completed' WHERE id=?").run(a.id);
  res.json({ok:true});
});

app.get("/api/appointments",auth,(req,res)=>{
  let rows;
  if(req.user.role==="patient"){
    rows=db.prepare(`SELECT a.*,u.name doctor_name,d.specialty FROM appointments a JOIN doctors d ON d.id=a.doctor_id JOIN users u ON u.id=d.user_id WHERE a.patient_id=? ORDER BY date,time DESC`).all(req.user.id);
  } else if(req.user.role==="doctor"){
    const d=db.prepare("SELECT id FROM doctors WHERE user_id=?").get(req.user.id);
    rows=db.prepare(`SELECT a.*,u.name patient_name FROM appointments a JOIN users u ON u.id=a.patient_id WHERE a.doctor_id=? ORDER BY date,time`).all(d?.id||-1);
  } else {
    rows=db.prepare(`SELECT a.*,p.name patient_name,du.name doctor_name,d.specialty FROM appointments a JOIN users p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id JOIN users du ON du.id=d.user_id ORDER BY a.created_at DESC`).all();
  }
  res.json(rows);
});


const PARSIAN_HOST="https://pec.shaparak.ir";
const PARSIAN_SALE_URL=`${PARSIAN_HOST}/NewIPGServices/Sale/SaleService.asmx`;
const PARSIAN_CONFIRM_URL=`${PARSIAN_HOST}/NewIPGServices/Confirm/ConfirmService.asmx`;
const PARSIAN_PAYMENT_URL=`${PARSIAN_HOST}/NewIPG/`;
const PARSIAN_LOGIN=process.env.PARSIAN_LOGIN_ACCOUNT||"";
const PUBLIC_BASE_URL=(process.env.PUBLIC_BASE_URL||process.env.FRONTEND_URL||"").replace(/\/$/,"");

function xmlEscape(v){return String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");}
async function parsianSoap(url,method,requestData){
  const ns=method==="SalePaymentRequest"
    ?"https://pec.Shaparak.ir/NewIPGServices/Sale/SaleService"
    :"https://pec.Shaparak.ir/NewIPGServices/Confirm/ConfirmService";
  const fields=Object.entries(requestData).map(([k,v])=>`<${k}>${xmlEscape(v)}</${k}>`).join("");
  const body=`<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><${method} xmlns="${ns}"><requestData>${fields}</requestData></${method}></soap:Body></soap:Envelope>`;
  const r=await fetch(url,{method:"POST",headers:{"Content-Type":"text/xml; charset=utf-8","SOAPAction":`"${ns}/${method}"`},body,signal:AbortSignal.timeout(15000)});
  if(!r.ok)throw new Error(`Parsian HTTP ${r.status}`);
  return await r.text();
}
function xmlValue(xml,name){
  const m=xml.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`,"i"));
  return m?m[1].replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">"):"";
}
function newOrderId(){return Number(`${Date.now()}${crypto.randomInt(100,999)}`.slice(-15));}
function requireParsian(res){
  if(!PARSIAN_LOGIN||!PUBLIC_BASE_URL)return res.status(503).json({error:"درگاه پارسیان پیکربندی نشده است. PARSIAN_LOGIN_ACCOUNT و PUBLIC_BASE_URL را تنظیم کنید."});
  if(!PUBLIC_BASE_URL.startsWith("https://"))return res.status(503).json({error:"PUBLIC_BASE_URL باید HTTPS باشد."});
  return true;
}
app.post("/api/appointments",auth,role("patient"),async(req,res)=>{
  const s=z.object({doctor_id:z.number().int(),date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),time:z.string().regex(/^\d{2}:\d{2}$/),visit_type:z.enum(["حضوری","آنلاین"])}).safeParse(req.body);
  if(!s.success)return res.status(400).json({error:"اطلاعات نوبت نامعتبر است"});
  const doctor=db.prepare("SELECT * FROM doctors WHERE id=?").get(s.data.doctor_id);
  if(!doctor)return res.status(404).json({error:"پزشک پیدا نشد"});
  try{
    const info=db.prepare(`INSERT INTO appointments(patient_id,doctor_id,date,time,visit_type,amount,status,payment_status) VALUES(?,?,?,?,?,?,?,?)`)
      .run(req.user.id,doctor.id,s.data.date,s.data.time,s.data.visit_type,doctor.fee,"pending","unpaid");
    res.status(201).json({id:info.lastInsertRowid,amount:doctor.fee,payment_mode:"parsian"});
  }catch(e){
    const existing=db.prepare(`SELECT id,payment_status,status,patient_id FROM appointments WHERE doctor_id=? AND date=? AND time=?`).get(doctor.id,s.data.date,s.data.time);
    if(existing && existing.patient_id===req.user.id && existing.payment_status!=="paid")
      return res.status(200).json({id:existing.id,amount:doctor.fee,payment_mode:"parsian",existing:true});
    res.status(409).json({error:"این زمان قبلاً رزرو شده است"});
  }
});

app.post("/api/payments/checkout",auth,role("patient"),async(req,res)=>{
  const id=Number(req.body.appointment_id);
  const a=db.prepare("SELECT * FROM appointments WHERE id=? AND patient_id=?").get(id,req.user.id);
  if(!a)return res.status(404).json({error:"نوبت پیدا نشد"});
  if(a.payment_status==="paid")return res.json({paid:true});
  if(!requireParsian(res))return;
  try{
    const orderId=newOrderId();
    const callback=`${PUBLIC_BASE_URL}/api/payments/parsian/callback`;
    const xml=await parsianSoap(PARSIAN_SALE_URL,"SalePaymentRequest",{LoginAccount:PARSIAN_LOGIN,Amount:a.amount,OrderId:orderId,CallBackUrl:callback,AdditionalData:`appointment_id=${a.id}`});
    const status=xmlValue(xml,"Status"), token=xmlValue(xml,"Token");
    if(String(status)!=="0"||!token)throw new Error(`Parsian request failed: ${status||"no status"}`);
    db.prepare(`UPDATE appointments SET payment_ref=?,payment_token=?,payment_gateway='parsian',payment_error=NULL,payment_status='pending' WHERE id=?`).run(String(orderId),token,id);
    res.json({mode:"parsian",url:`${PARSIAN_PAYMENT_URL}?Token=${encodeURIComponent(token)}`,appointment_id:id});
  }catch(e){
    db.prepare("UPDATE appointments SET payment_status='failed',status='pending',payment_gateway='parsian',payment_error=? WHERE id=?").run(String(e.message).slice(0,500),id);
    res.status(502).json({error:"ارتباط با درگاه پارسیان ناموفق بود؛ نوبت با وضعیت پرداخت‌نشده ثبت شد."});
  }
});

app.all("/api/payments/parsian/callback",async(req,res)=>{
  const q={...req.query,...req.body}, token=String(q.Token||q.token||""), orderId=String(q.OrderId||q.orderId||""), bankStatus=String(q.status??q.Status??"");
  let a=orderId?db.prepare("SELECT * FROM appointments WHERE payment_ref=?").get(orderId):null;
  if(!a&&token)a=db.prepare("SELECT * FROM appointments WHERE payment_token=?").get(token);
  if(!a)return res.status(404).send("نوبت پرداخت پیدا نشد.");
  if(a.payment_status==="paid")return res.redirect(`${PUBLIC_BASE_URL}/?payment=success&appointment=${a.id}`);
  if(bankStatus!=="0"||!token){
    db.prepare("UPDATE appointments SET payment_status='failed',status='pending',payment_error=? WHERE id=?").run(`بانک پرداخت را تأیید نکرد (status=${bankStatus||"unknown"})`,a.id);
    return res.redirect(`${PUBLIC_BASE_URL}/?payment=failed&appointment=${a.id}`);
  }
  try{
    const xml=await parsianSoap(PARSIAN_CONFIRM_URL,"ConfirmPayment",{LoginAccount:PARSIAN_LOGIN,Token:token});
    const status=xmlValue(xml,"Status"), rrn=xmlValue(xml,"RRN");
    if(String(status)==="0" && rrn){
      db.prepare(`UPDATE appointments SET payment_status='paid',status='confirmed',payment_ref=?,payment_error=NULL,payment_verified_at=CURRENT_TIMESTAMP WHERE id=?`).run(rrn,a.id);
      return res.redirect(`${PUBLIC_BASE_URL}/?payment=success&appointment=${a.id}`);
    }
    db.prepare("UPDATE appointments SET payment_status='failed',status='pending',payment_error=? WHERE id=?").run(`تأیید پارسیان ناموفق بود: ${status||"unknown"}`,a.id);
    return res.redirect(`${PUBLIC_BASE_URL}/?payment=failed&appointment=${a.id}`);
  }catch(e){
    db.prepare("UPDATE appointments SET payment_status='failed',status='pending',payment_error=? WHERE id=?").run(`خطا در Verify: ${String(e.message).slice(0,400)}`,a.id);
    return res.redirect(`${PUBLIC_BASE_URL}/?payment=failed&appointment=${a.id}`);
  }
});

app.get("/api/payments/appointment/:id",auth,role("patient"),(req,res)=>{
  const a=db.prepare("SELECT id,date,time,status,payment_status,payment_ref,payment_gateway,payment_error,payment_verified_at FROM appointments WHERE id=? AND patient_id=?").get(Number(req.params.id),req.user.id);
  if(!a)return res.status(404).json({error:"نوبت پیدا نشد"});
  res.json(a);
});

app.patch("/api/appointments/:id/status",auth,role("doctor","admin"),(req,res)=>{
  const status=z.enum(["confirmed","completed","cancelled","pending"]).safeParse(req.body.status);
  if(!status.success)return res.status(400).json({error:"وضعیت نامعتبر"});
  const id=Number(req.params.id);
  db.prepare("UPDATE appointments SET status=? WHERE id=?").run(status.data,id);
  res.json({ok:true});
});



app.get("/api/admin/doctors",auth,role("admin"),(req,res)=>{
  const rows=db.prepare(`SELECT d.id,d.user_id,u.name,u.email,u.phone,d.specialty,d.fee,d.bio
    FROM doctors d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC`).all();
  res.json(rows);
});
app.post("/api/admin/doctors",auth,role("admin"),(req,res)=>{
  const s=z.object({
    name:z.string().min(2).max(100),email:z.string().email(),phone:z.string().max(30).optional(),
    specialty:z.string().min(2).max(100),fee:z.number().int().positive().max(100000000),
    bio:z.string().max(5000).optional(),password:z.string().min(8).optional()
  }).safeParse(req.body);
  if(!s.success)return res.status(400).json({error:"اطلاعات پزشک نامعتبر است"});
  try{
    const exists=db.prepare("SELECT id FROM users WHERE email=?").get(s.data.email);
    if(exists)return res.status(409).json({error:"این ایمیل قبلاً استفاده شده است"});
    const hash=bcrypt.hashSync(s.data.password||"Doctor123!",12);
    const u=db.prepare("INSERT INTO users(name,email,phone,password_hash,role) VALUES(?,?,?,?,?)")
      .run(s.data.name,s.data.email,s.data.phone||"",hash,"doctor");
    const d=db.prepare("INSERT INTO doctors(user_id,specialty,fee,bio) VALUES(?,?,?,?)")
      .run(u.lastInsertRowid,s.data.specialty,s.data.fee,s.data.bio||"");
    res.status(201).json({id:d.lastInsertRowid});
  }catch(e){res.status(500).json({error:"افزودن پزشک ناموفق بود"});}
});
app.put("/api/admin/doctors/:id",auth,role("admin"),(req,res)=>{
  const id=Number(req.params.id);
  const s=z.object({
    name:z.string().min(2).max(100),email:z.string().email(),phone:z.string().max(30).optional(),
    specialty:z.string().min(2).max(100),fee:z.number().int().positive().max(100000000),
    bio:z.string().max(5000).optional()
  }).safeParse(req.body);
  if(!s.success)return res.status(400).json({error:"اطلاعات پزشک نامعتبر است"});
  const d=db.prepare("SELECT user_id FROM doctors WHERE id=?").get(id);
  if(!d)return res.status(404).json({error:"پزشک پیدا نشد"});
  try{
    db.prepare("UPDATE users SET name=?,email=?,phone=? WHERE id=?")
      .run(s.data.name,s.data.email,s.data.phone||"",d.user_id);
    db.prepare("UPDATE doctors SET specialty=?,fee=?,bio=? WHERE id=?")
      .run(s.data.specialty,s.data.fee,s.data.bio||"",id);
    res.json({ok:true});
  }catch(e){res.status(409).json({error:"ایمیل پزشک تکراری است یا اطلاعات نامعتبر است"});}
});
app.delete("/api/admin/doctors/:id",auth,role("admin"),(req,res)=>{
  const id=Number(req.params.id);
  const d=db.prepare("SELECT user_id FROM doctors WHERE id=?").get(id);
  if(!d)return res.status(404).json({error:"پزشک پیدا نشد"});
  const active=db.prepare("SELECT COUNT(*) c FROM appointments WHERE doctor_id=? AND status IN ('pending','confirmed')").get(id).c;
  if(active)return res.status(409).json({error:"پزشک نوبت فعال دارد؛ ابتدا نوبت‌های فعال را مدیریت کنید"});
  const tx=db.transaction(()=>{
    db.prepare("DELETE FROM doctors WHERE id=?").run(id);
    db.prepare("DELETE FROM users WHERE id=?").run(d.user_id);
  });
  tx();
  res.json({ok:true});
});

app.post("/api/admin/backup",auth,role("admin"),async(req,res)=>{
  try{
    const dir=process.env.BACKUP_DIR||"./backups"; fs.mkdirSync(dir,{recursive:true});
    const stamp=new Date().toISOString().replace(/[:.]/g,"-");
    const target=path.join(dir,`pezeshkyar-${stamp}.db`);
    const backupDb=new Database("pezeshkyar.db",{readonly:true});
    await backupDb.backup(target); backupDb.close();
    const st=fs.statSync(target);
    db.prepare("INSERT INTO backup_logs(path,size_bytes) VALUES(?,?)").run(target,st.size);
    res.json({ok:true,path:target,size_bytes:st.size});
  }catch(e){res.status(500).json({error:"پشتیبان‌گیری ناموفق بود"});}
});
app.get("/api/admin/backups",auth,role("admin"),(req,res)=>{
  res.json(db.prepare("SELECT * FROM backup_logs ORDER BY created_at DESC LIMIT 50").all());
});

app.get("/api/admin/stats",auth,role("admin"),(req,res)=>{
  res.json({
    users:db.prepare("SELECT COUNT(*) c FROM users").get().c,
    doctors:db.prepare("SELECT COUNT(*) c FROM doctors").get().c,
    appointments:db.prepare("SELECT COUNT(*) c FROM appointments").get().c,
    paid:db.prepare("SELECT COALESCE(SUM(amount),0) c FROM appointments WHERE payment_status='paid'").get().c
  });
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
const tlsEnabled=String(process.env.HTTPS_ENABLED||"false").toLowerCase()==="true";
const httpsPort=Number(process.env.HTTPS_PORT||3443);
if(tlsEnabled){
  const key=fs.readFileSync(process.env.TLS_KEY_PATH||"./certs/server.key");
  const cert=fs.readFileSync(process.env.TLS_CERT_PATH||"./certs/server.crt");
  https.createServer({key,cert},app).listen(httpsPort,()=>console.log(`پزشک‌یار HTTPS: https://localhost:${httpsPort}`));
} else {
  http.createServer(app).listen(PORT,()=>console.log(`پزشک‌یار HTTP: http://localhost:${PORT}`));
}
// ---------- Doctor subscriptions ----------
app.get("/api/subscriptions/plans",auth,(req,res)=>{
 const rows=db.prepare("SELECT * FROM subscription_plans WHERE active=1 ORDER BY price").all();
 rows.forEach(x=>{try{x.features=JSON.parse(x.features||"[]")}catch{x.features=[]}});
 res.json(rows);
});
app.get("/api/admin/subscriptions/plans",auth,role("admin"),(req,res)=>{
 const rows=db.prepare("SELECT * FROM subscription_plans ORDER BY id DESC").all();
 rows.forEach(x=>{try{x.features=JSON.parse(x.features||"[]")}catch{x.features=[]}});
 res.json(rows);
});
app.post("/api/admin/subscriptions/plans",auth,role("admin"),(req,res)=>{
 const {name,duration_days,price,features=[]}=req.body||{};
 if(!name||!Number(duration_days)||Number(price)<0)return res.status(400).json({error:"اطلاعات پلن نامعتبر است"});
 const r=db.prepare("INSERT INTO subscription_plans(name,duration_days,price,features,active) VALUES(?,?,?,?,1)")
  .run(String(name),Number(duration_days),Number(price),JSON.stringify(Array.isArray(features)?features:[]));
 res.status(201).json({id:r.lastInsertRowid});
});
app.patch("/api/admin/subscriptions/plans/:id",auth,role("admin"),(req,res)=>{
 const p=db.prepare("SELECT * FROM subscription_plans WHERE id=?").get(Number(req.params.id));
 if(!p)return res.status(404).json({error:"پلن پیدا نشد"});
 const name=req.body.name??p.name, days=req.body.duration_days??p.duration_days, price=req.body.price??p.price;
 const features=req.body.features??JSON.parse(p.features||"[]"), active=req.body.active??p.active;
 db.prepare("UPDATE subscription_plans SET name=?,duration_days=?,price=?,features=?,active=? WHERE id=?")
  .run(String(name),Number(days),Number(price),JSON.stringify(features),active?1:0,p.id);
 res.json({ok:true});
});
app.get("/api/admin/subscriptions",auth,role("admin"),(req,res)=>{
 const rows=db.prepare(`SELECT ds.*,sp.name plan_name,sp.price,sp.duration_days,u.name doctor_name,u.phone
 FROM doctor_subscriptions ds JOIN subscription_plans sp ON sp.id=ds.plan_id
 JOIN doctors d ON d.id=ds.doctor_id JOIN users u ON u.id=d.user_id
 ORDER BY ds.created_at DESC LIMIT 200`).all();
 res.json(rows);
});
app.get("/api/doctor/subscription",auth,role("doctor"),(req,res)=>{
 const d=db.prepare("SELECT id FROM doctors WHERE user_id=?").get(req.user.id);
 if(!d)return res.status(404).json({error:"پروفایل پزشک پیدا نشد"});
 const current=db.prepare(`SELECT ds.*,sp.name plan_name,sp.features,sp.price,sp.duration_days
 FROM doctor_subscriptions ds JOIN subscription_plans sp ON sp.id=ds.plan_id
 WHERE ds.doctor_id=? ORDER BY ds.created_at DESC LIMIT 1`).get(d.id);
 if(current){try{current.features=JSON.parse(current.features||"[]")}catch{current.features=[]}}
 res.json(current||null);
});
app.post("/api/doctor/subscriptions/purchase",auth,role("doctor"),async(req,res)=>{
 const plan=db.prepare("SELECT * FROM subscription_plans WHERE id=? AND active=1").get(Number(req.body.plan_id));
 const d=db.prepare("SELECT id FROM doctors WHERE user_id=?").get(req.user.id);
 if(!d||!plan)return res.status(404).json({error:"پزشک یا پلن پیدا نشد"});
 const r=db.prepare(`INSERT INTO doctor_subscriptions(doctor_id,plan_id,status,payment_status) VALUES(?,?,?,?)`)
  .run(d.id,plan.id,"pending","unpaid");
 const subId=r.lastInsertRowid;
 // Reuse the already configured PEC integration.
 const login=process.env.PARSIAN_LOGIN_ACCOUNT||"", base=(process.env.PUBLIC_BASE_URL||"").replace(/\/$/,"");
 if(!login||!base.startsWith("https://"))return res.status(503).json({error:"درگاه پارسیان برای اشتراک پیکربندی نشده است."});
 try{
  const orderId=Number(`${Date.now()}${Math.floor(Math.random()*900+100)}`.slice(-15));
  const callback=`${base}/api/subscriptions/parsian/callback`;
  const ns="https://pec.Shaparak.ir/NewIPGServices/Sale/SaleService";
  const esc=v=>String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  const fields=`<LoginAccount>${esc(login)}</LoginAccount><Amount>${plan.price}</Amount><OrderId>${orderId}</OrderId><CallBackUrl>${esc(callback)}</CallBackUrl><AdditionalData>subscription_id=${subId}</AdditionalData>`;
  const body=`<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><SalePaymentRequest xmlns="${ns}"><requestData>${fields}</requestData></SalePaymentRequest></soap:Body></soap:Envelope>`;
  const rr=await fetch("https://pec.shaparak.ir/NewIPGServices/Sale/SaleService.asmx",{method:"POST",headers:{"Content-Type":"text/xml; charset=utf-8","SOAPAction":`"${ns}/SalePaymentRequest"`},body,signal:AbortSignal.timeout(15000)});
  const xml=await rr.text(), sm=xml.match(/<Status>([\s\S]*?)<\/Status>/i), tm=xml.match(/<Token>([\s\S]*?)<\/Token>/i);
  const status=sm?sm[1]:"", token=tm?tm[1]:"";
  if(status!=="0"||!token)throw new Error("Parsian sale failed");
  db.prepare("UPDATE doctor_subscriptions SET payment_ref=?,payment_token=? WHERE id=?").run(String(orderId),token,subId);
  db.prepare("INSERT INTO subscription_payments(doctor_subscription_id,amount,gateway,status,reference) VALUES(?,?,?,?,?)").run(subId,plan.price,"parsian","pending",String(orderId));
  res.json({url:`https://pec.shaparak.ir/NewIPG/?Token=${encodeURIComponent(token)}`,subscription_id:subId});
 }catch(e){
  db.prepare("UPDATE doctor_subscriptions SET payment_status='failed',status='pending',payment_error=? WHERE id=?").run(String(e.message).slice(0,400),subId);
  res.status(502).json({error:"ایجاد پرداخت اشتراک ناموفق بود؛ اشتراک فعال نشد."});
 }
});
app.all("/api/subscriptions/parsian/callback",async(req,res)=>{
 const q={...req.query,...req.body}, token=String(q.Token||q.token||""), orderId=String(q.OrderId||q.orderId||""), bankStatus=String(q.Status??q.status??"");
 let sub=orderId?db.prepare("SELECT * FROM doctor_subscriptions WHERE payment_ref=?").get(orderId):null;
 if(!sub&&token)sub=db.prepare("SELECT * FROM doctor_subscriptions WHERE payment_token=?").get(token);
 if(!sub)return res.status(404).send("اشتراک پرداخت پیدا نشد.");
 if(bankStatus!=="0"||!token){
  db.prepare("UPDATE doctor_subscriptions SET payment_status='failed',status='pending',payment_error=? WHERE id=?").run(`bank status ${bankStatus}`,sub.id);
  db.prepare("UPDATE subscription_payments SET status='failed' WHERE doctor_subscription_id=? AND status='pending'").run(sub.id);
  return res.redirect(`${process.env.PUBLIC_BASE_URL}/?subscription=failed&id=${sub.id}`);
 }
 try{
  const login=process.env.PARSIAN_LOGIN_ACCOUNT||"";
  const ns="https://pec.Shaparak.ir/NewIPGServices/Confirm/ConfirmService";
  const esc=v=>String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  const fields=`<LoginAccount>${esc(login)}</LoginAccount><Token>${esc(token)}</Token>`;
  const body=`<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><ConfirmPayment xmlns="${ns}"><requestData>${fields}</requestData></ConfirmPayment></soap:Body></soap:Envelope>`;
  const rr=await fetch("https://pec.shaparak.ir/NewIPGServices/Confirm/ConfirmService.asmx",{method:"POST",headers:{"Content-Type":"text/xml; charset=utf-8","SOAPAction":`"${ns}/ConfirmPayment"`},body,signal:AbortSignal.timeout(15000)});
  const xml=await rr.text(), sm=xml.match(/<Status>([\s\S]*?)<\/Status>/i), rm=xml.match(/<RRN>([\s\S]*?)<\/RRN>/i);
  if(sm&&sm[1]==="0"&&rm&&rm[1]){
   const plan=db.prepare("SELECT * FROM subscription_plans WHERE id=?").get(sub.plan_id);
   const now=new Date(), current=db.prepare(`SELECT ends_at FROM doctor_subscriptions WHERE doctor_id=? AND status='active' AND ends_at>? ORDER BY ends_at DESC LIMIT 1`).get(sub.doctor_id,now.toISOString());
   const start=current?new Date(current.ends_at):now, end=new Date(start.getTime()+plan.duration_days*86400000);
   db.prepare(`UPDATE doctor_subscriptions SET status='active',payment_status='paid',starts_at=?,ends_at=?,payment_verified_at=CURRENT_TIMESTAMP,payment_error=NULL,payment_ref=? WHERE id=?`).run(start.toISOString(),end.toISOString(),rm[1],sub.id);
   db.prepare("UPDATE subscription_payments SET status='paid',reference=? WHERE doctor_subscription_id=? AND status='pending'").run(rm[1],sub.id);
   return res.redirect(`${process.env.PUBLIC_BASE_URL}/?subscription=success&id=${sub.id}`);
  }
  throw new Error("Verify failed");
 }catch(e){
  db.prepare("UPDATE doctor_subscriptions SET payment_status='failed',status='pending',payment_error=? WHERE id=?").run(String(e.message).slice(0,400),sub.id);
  db.prepare("UPDATE subscription_payments SET status='failed' WHERE doctor_subscription_id=? AND status='pending'").run(sub.id);
  return res.redirect(`${process.env.PUBLIC_BASE_URL}/?subscription=failed&id=${sub.id}`);
 }
});



// ---------- Admin free/disable doctor subscriptions ----------
app.post("/api/admin/subscriptions/free-activate",auth,role("admin"),(req,res)=>{
 const doctorId=Number(req.body.doctor_id), planId=Number(req.body.plan_id);
 const days=Number(req.body.duration_days||0);
 const d=db.prepare("SELECT id FROM doctors WHERE id=?").get(doctorId);
 const p=db.prepare("SELECT * FROM subscription_plans WHERE id=? AND active=1").get(planId);
 if(!d||!p)return res.status(404).json({error:"پزشک یا پلن پیدا نشد"});
 if(!days||days<1||days>3650)return res.status(400).json({error:"مدت رایگان باید بین ۱ تا ۳۶۵۰ روز باشد"});
 const now=new Date();
 const current=db.prepare(`SELECT ends_at FROM doctor_subscriptions WHERE doctor_id=? AND status='active' AND ends_at>? ORDER BY ends_at DESC LIMIT 1`).get(doctorId,now.toISOString());
 const start=current?new Date(current.ends_at):now, end=new Date(start.getTime()+days*86400000);
 const r=db.prepare(`INSERT INTO doctor_subscriptions(doctor_id,plan_id,starts_at,ends_at,status,payment_status,payment_error,activation_source,activated_by)
 VALUES(?,?,?,?,?,?,?,?,?)`).run(doctorId,planId,start.toISOString(),end.toISOString(),"active","paid","فعال‌سازی رایگان توسط مدیر","admin_free",req.user.id);
 res.status(201).json({id:r.lastInsertRowid,starts_at:start.toISOString(),ends_at:end.toISOString(),activation_source:"admin_free"});
});
app.post("/api/admin/subscriptions/:id/disable",auth,role("admin"),(req,res)=>{
 const id=Number(req.params.id);
 const sub=db.prepare("SELECT * FROM doctor_subscriptions WHERE id=?").get(id);
 if(!sub)return res.status(404).json({error:"اشتراک پیدا نشد"});
 db.prepare(`UPDATE doctor_subscriptions SET status='disabled',disabled_at=CURRENT_TIMESTAMP,disabled_by=?,payment_error=? WHERE id=?`)
  .run(req.user.id,"غیرفعال‌شده توسط مدیر",id);
 res.json({ok:true});
});
app.post("/api/admin/subscriptions/:id/enable",auth,role("admin"),(req,res)=>{
 const id=Number(req.params.id);
 const sub=db.prepare("SELECT * FROM doctor_subscriptions WHERE id=?").get(id);
 if(!sub)return res.status(404).json({error:"اشتراک پیدا نشد"});
 if(!sub.ends_at||new Date(sub.ends_at)<=new Date())return res.status(400).json({error:"این اشتراک منقضی شده و قابل فعال‌سازی مجدد نیست"});
 db.prepare(`UPDATE doctor_subscriptions SET status='active',disabled_at=NULL,disabled_by=NULL,payment_error=NULL WHERE id=?`).run(id);
 res.json({ok:true});
});
app.get("/api/admin/doctors-for-subscription",auth,role("admin"),(req,res)=>{
 const rows=db.prepare(`SELECT d.id,u.name,u.phone,u.email FROM doctors d JOIN users u ON u.id=d.user_id ORDER BY u.name`).all();
 res.json(rows);
});

// ---------- Parsian payment admin panel ----------
app.get("/api/admin/payments/parsian",auth,role("admin"),(req,res)=>{
 const q=String(req.query.q||"").trim(), status=String(req.query.status||"").trim(), type=String(req.query.type||"").trim();
 const like=`%${q}%`;
 const appointments=db.prepare(`SELECT a.id,a.amount,a.payment_status,a.status,a.payment_ref,a.payment_gateway,a.payment_error,a.payment_verified_at,a.created_at,
   'appointment' type,u.name customer_name,u.phone,d.specialty FROM appointments a
   JOIN users u ON u.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id
   WHERE a.payment_gateway='parsian' AND (?='' OR a.payment_status=?) AND (?='' OR CAST(a.id AS TEXT) LIKE ? OR u.name LIKE ? OR u.phone LIKE ?)
   ORDER BY a.created_at DESC LIMIT 500`).all(status,status,q,like,like,like);
 const subs=db.prepare(`SELECT ds.id,sp.price amount,ds.payment_status,ds.status,ds.payment_ref,ds.payment_error,ds.payment_verified_at,ds.created_at,
   'subscription' type,u.name customer_name,u.phone,sp.name specialty FROM doctor_subscriptions ds
   JOIN subscription_plans sp ON sp.id=ds.plan_id JOIN doctors d ON d.id=ds.doctor_id JOIN users u ON u.id=d.user_id
   WHERE ds.payment_ref IS NOT NULL AND (?='' OR ds.payment_status=?) AND (?='' OR CAST(ds.id AS TEXT) LIKE ? OR u.name LIKE ? OR u.phone LIKE ?)
   ORDER BY ds.created_at DESC LIMIT 500`).all(status,status,q,like,like,like);
 let rows=[...appointments,...subs].filter(x=>!type||x.type===type).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)));
 const summary={count:rows.length,paid:rows.filter(x=>x.payment_status==="paid").length,failed:rows.filter(x=>x.payment_status==="failed").length,pending:rows.filter(x=>x.payment_status==="pending").length,totalPaid:rows.filter(x=>x.payment_status==="paid").reduce((n,x)=>n+Number(x.amount||0),0)};
 res.json({summary,rows});
});
app.get("/api/admin/payments/parsian/settings",auth,role("admin"),(req,res)=>{
 res.json({configured:!!process.env.PARSIAN_LOGIN_ACCOUNT,httpsBase:String(process.env.PUBLIC_BASE_URL||"").startsWith("https://"),baseUrl:process.env.PUBLIC_BASE_URL||""});
});

