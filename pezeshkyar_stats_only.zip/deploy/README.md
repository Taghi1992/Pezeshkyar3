# استقرار امن پیشنهادی

در محیط واقعی بهتر است TLS در Nginx/Load Balancer terminate شود و Node روی localhost اجرا شود.

نمونه:
1. دامنه را به سرور وصل کنید.
2. با Certbot یک گواهی معتبر Let's Encrypt بگیرید.
3. `deploy/nginx.conf` را با دامنه واقعی تنظیم کنید.
4. Node را فقط روی localhost اجرا کنید.
5. `.env` و کلید JWT را خارج از repository نگه دارید.
6. `npm run backup` را با cron/systemd timer روزانه اجرا کنید.
7. پوشه backup را روی storage جداگانه و ترجیحاً رمزنگاری‌شده/off-site کپی کنید.
8. به صورت دوره‌ای restore را روی محیط جداگانه آزمایش کنید.

برای محیط درمانی، backup تنها وقتی مفید است که restore آن واقعاً تست شده باشد.
