#!/usr/bin/env bash
set -e
mkdir -p certs
openssl req -x509 -newkey rsa:3072 -nodes -keyout certs/server.key -out certs/server.crt -days 365 \
  -subj "/C=AZ/ST=Baku/L=Baku/O=Pezeshkyar/CN=localhost"
chmod 600 certs/server.key
echo "Development certificate created. Do not use this self-signed certificate in production."
